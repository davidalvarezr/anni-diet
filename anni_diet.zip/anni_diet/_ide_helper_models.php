<?php

// @formatter:off
/**
 * A helper file for your Eloquent Models
 * Copy the phpDocs from this file to the correct Model,
 * And remove them from this file, to prevent double declarations.
 *
 * @author Barry vd. Heuvel <barryvdh@gmail.com>
 */


namespace App\Models{
/**
 * App\Models\Firework
 *
 * @property int $id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string $x
 * @property string $y
 * @property string $z
 * @property string $type
 * @property int|null $triggered_by
 * @property int $user_id
 * @property-read \App\Models\User|null $triggeredBy
 * @property-read \App\Models\User $user
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Firework newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Firework newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Firework query()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Firework whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Firework whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Firework whereTriggeredBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Firework whereType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Firework whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Firework whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Firework whereX($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Firework whereY($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Firework whereZ($value)
 */
	class Firework extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\User
 *
 * @property int $id
 * @property string $name
 * @property string $email
 * @property \Illuminate\Support\Carbon|null $email_verified_at
 * @property string $password
 * @property string|null $remember_token
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\Laravel\Passport\Client[] $clients
 * @property-read int|null $clients_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Firework[] $fireworks
 * @property-read int|null $fireworks_count
 * @property-read \Illuminate\Notifications\DatabaseNotificationCollection|\Illuminate\Notifications\DatabaseNotification[] $notifications
 * @property-read int|null $notifications_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Laravel\Passport\Token[] $tokens
 * @property-read int|null $tokens_count
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\User newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\User newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\User query()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\User whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\User whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\User whereEmailVerifiedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\User whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\User whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\User wherePassword($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\User whereRememberToken($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\User whereUpdatedAt($value)
 */
	class User extends \Eloquent {}
}

