@extends('layouts.app')

@section('content')
    <main-menu
        token="{{$token}}"
    ></main-menu>
@endsection
