

<?php $__env->startSection('content'); ?>
    <web-socket-emitter></web-socket-emitter>

    <div class="mt-5"></div>

    <firework-trigger></firework-trigger>

    <div class="mt-5"></div>

    <web-socket-receiver
        pusher-app-key="<?php echo e(env('PUSHER_APP_KEY')); ?>"
        pusher-app-cluster="<?php echo e(env('PUSHER_APP_CLUSTER')); ?>"
        pusher-auth-endpoint="<?php echo e(route('pusher-api-auth')); ?>"
    ></web-socket-receiver>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/websocket.blade.php ENDPATH**/ ?>