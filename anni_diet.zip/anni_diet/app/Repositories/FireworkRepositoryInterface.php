<?php

namespace App\Repositories;

interface FireworkRepositoryInterface {

    public function getAllFireworksNotTriggered();

}
